Duelito (The Duel)
�1999 Hass�n Hern�ndez Ben�tez (alias Bokudono or Bokuten).

Playing is easy. Just move to left and right, and press A for jump.


Note: NESticle makes the floor to appear lower. As it is the most
popular emulator, the game is adapted to it and is supposed to
look correctly, but in other emulators or different versions of
NESticle it may look bad.


I would like to thank:

YOSHi		for his document (obvious)

Tony Young	With his page and demo I began to understand YOSHi's document
		(http://members.aol.com/TYoung79/nesprog.html)

Thomas N. Anderson	for TASM

Jonathan Bowen	for his summary of the 6502 instruction set

Chris Covell	for RGB
		(http://mypage.direct.ca/c/ccovell/)

Snow Bro	for Tile Layer
		SnowBro Software (http://home.sol.no/~kenhanse/nes/)


Questions/suggestions:	hebhassan@hotmail.com
		Waseiyakusha(http://members.xoom.com/has_san/index.html)



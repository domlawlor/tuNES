OAM = $0200

.global OAM
